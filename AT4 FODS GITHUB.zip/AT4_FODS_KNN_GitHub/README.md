# AT4 – Fundamentals of Data Science (KNN Answers)

This repository contains simple-English text answers for all 10 questions in the
AT4 Fundamentals of Data Science assignment (Course Code: DSA04, CO4).

## Files

- `AT4_KNN_Answers.txt` – Complete answers, including feature identification,
  distance tables, three nearest neighbours, predictions, comparisons, and conclusion.
- `README.md` – This file.

## Topics covered

1. Student Pass or Fail Prediction
2. Online Customer Purchase Prediction
3. Medical Risk Classification
4. Fruit Classification
5. House Price Category Prediction
6. Loan Approval Prediction
7. Movie Preference Classification
8. Crop Disease Detection
9. Network Intrusion Detection
10. Employee Attrition Prediction

## Upload to GitHub

1. Download the ZIP folder.
2. Extract it on your computer.
3. Open GitHub and create a new repository.
4. Open the repository and choose **Add file → Upload files**.
5. Upload `README.md` and `AT4_KNN_Answers.txt`.
6. Enter a commit message, such as `Add AT4 KNN assignment answers`.
7. Click **Commit changes**.

## Calculation note

The answers use numerical features for Euclidean, Manhattan, and Minkowski
distances, and binary features for Hamming distance, following the assignment
instructions. Numerical features have not been normalized. Tied distances can
allow more than one valid selection of nearest neighbours.
