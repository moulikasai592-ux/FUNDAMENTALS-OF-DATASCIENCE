# Fundamentals of Data Science – EDA Practical Assessment

This GitHub project contains the five datasets and Python code for the Exploratory Data Analysis (EDA) assessment.

## Project contents

- `datasets/` – CSV files for all five assessment questions.
- `eda_assessment.py` – loads each CSV, checks data quality, calculates descriptive statistics, prints useful group summaries, and creates charts.
- `requirements.txt` – Python libraries needed to run the project.
- `outputs/` – generated charts are saved here after running the script.

## Datasets included

1. Education Analytics – attendance, study hours, internal marks and pass/fail result.
2. Healthcare Analytics – age, sugar level, blood pressure, BMI and disease status.
3. Retail Sales – category, price, quantity sold, discount and revenue.
4. Banking Loan Approval – income, credit score, loan amount, employment type and loan status.
5. Agriculture Crop Yield – rainfall, temperature, fertilizer usage, soil type and crop yield.

Each dataset contains 20 records, as provided in the assessment document.

## How to run

1. Install Python 3.9 or later.
2. Open a terminal in this project folder.
3. Install the required libraries:

   ```bash
   pip install -r requirements.txt
   ```

4. Run the analysis:

   ```bash
   python eda_assessment.py
   ```

The script prints row/column counts, data types, missing values, duplicate counts and descriptive statistics. It also saves charts in the `outputs/` folder.

## EDA tasks covered

- Dataset shape and data types
- Missing-value and duplicate checks
- Mean, median, minimum, maximum and standard deviation
- Group-wise comparisons for target variables
- Bar charts, histograms, scatter plots and box plots
- Short data-based observations and conclusions

## Important note

The healthcare and banking findings are descriptive patterns in these small sample datasets. They should not be treated as medical diagnoses or real-world loan approval rules.
