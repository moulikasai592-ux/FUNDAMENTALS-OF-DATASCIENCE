from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "datasets"
OUT = ROOT / "outputs"
OUT.mkdir(exist_ok=True)

FILES = {
    "education": "education_analytics.csv",
    "healthcare": "healthcare_analytics.csv",
    "retail": "retail_sales.csv",
    "banking": "banking_loan_approval.csv",
    "agriculture": "agriculture_crop_yield.csv",
}

def basic_eda(name, df):
    print(f"\n{'=' * 65}\n{name.upper()} DATASET\n{'=' * 65}")
    print("Shape (rows, columns):", df.shape)
    print("\nData types:\n", df.dtypes)
    print("\nMissing values:\n", df.isnull().sum())
    print("\nDuplicate rows:", df.duplicated().sum())
    print("\nDescriptive statistics:\n", df.describe(include="all").transpose())

def save_bar(series, title, xlabel, ylabel, filename):
    ax = series.plot(kind="bar", title=title, figsize=(7, 4))
    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    plt.tight_layout()
    plt.savefig(OUT / filename, dpi=150)
    plt.close()

def save_scatter(df, x, y, title, filename):
    plt.figure(figsize=(7, 4))
    plt.scatter(df[x], df[y])
    plt.title(title)
    plt.xlabel(x)
    plt.ylabel(y)
    plt.tight_layout()
    plt.savefig(OUT / filename, dpi=150)
    plt.close()

def save_hist_box(df, column, prefix):
    plt.figure(figsize=(7, 4))
    df[column].plot(kind="hist", bins=8, title=f"{column} distribution")
    plt.xlabel(column)
    plt.tight_layout()
    plt.savefig(OUT / f"{prefix}_{column.lower()}_histogram.png", dpi=150)
    plt.close()

    plt.figure(figsize=(6, 3))
    plt.boxplot(df[column].dropna(), vert=False)
    plt.title(f"{column} box plot")
    plt.xlabel(column)
    plt.tight_layout()
    plt.savefig(OUT / f"{prefix}_{column.lower()}_boxplot.png", dpi=150)
    plt.close()

def main():
    frames = {key: pd.read_csv(DATA / filename) for key, filename in FILES.items()}
    for key, df in frames.items():
        basic_eda(key, df)

    # 1. Education
    edu = frames["education"]
    print("\nEducation result counts:\n", edu["Result"].value_counts())
    print("\nEducation averages by result:\n",
          edu.groupby("Result")[["Attendance", "Study_Hours", "Internal_Marks"]].mean().round(2))
    save_bar(edu["Result"].value_counts(), "Student Result Counts",
             "Result", "Number of students", "education_result_counts.png")
    save_scatter(edu, "Attendance", "Internal_Marks",
                 "Attendance vs Internal Marks", "education_attendance_marks.png")
    for c in ["Attendance", "Study_Hours", "Internal_Marks"]:
        save_hist_box(edu, c, "education")

    # 2. Healthcare
    health = frames["healthcare"]
    print("\nHealthcare disease counts:\n", health["Disease_Status"].value_counts())
    print("\nHealthcare averages by disease status:\n",
          health.groupby("Disease_Status")[["Age", "Sugar_Level", "BP", "BMI"]].mean().round(2))
    save_bar(health["Disease_Status"].value_counts(), "Disease Status Counts",
             "Disease status", "Number of patients", "healthcare_status_counts.png")
    save_scatter(health, "Sugar_Level", "BMI",
                 "Blood Sugar vs BMI", "healthcare_sugar_bmi.png")
    for c in ["Age", "Sugar_Level", "BP", "BMI"]:
        save_hist_box(health, c, "healthcare")

    # 3. Retail
    retail = frames["retail"]
    category_summary = retail.groupby("Category").agg(
        Total_Quantity=("Quantity_Sold", "sum"),
        Total_Revenue=("Revenue", "sum")
    )
    print("\nRetail category summary:\n", category_summary)
    print("\nHighest quantity product:\n", retail.loc[retail["Quantity_Sold"].idxmax()])
    print("\nHighest revenue product:\n", retail.loc[retail["Revenue"].idxmax()])
    save_bar(category_summary["Total_Revenue"], "Total Revenue by Category",
             "Category", "Revenue", "retail_revenue_by_category.png")
    save_scatter(retail, "Quantity_Sold", "Revenue",
                 "Quantity Sold vs Revenue", "retail_quantity_revenue.png")
    for c in ["Price", "Quantity_Sold", "Discount", "Revenue"]:
        save_hist_box(retail, c, "retail")

    # 4. Banking
    bank = frames["banking"]
    print("\nLoan status counts:\n", bank["Loan_Status"].value_counts())
    print("\nBanking averages by loan status:\n",
          bank.groupby("Loan_Status")[["Income", "Credit_Score", "Loan_Amount"]].mean().round(2))
    print("\nEmployment type counts:\n", bank["Employment_Type"].value_counts())
    save_bar(bank["Loan_Status"].value_counts(), "Loan Approval Status Counts",
             "Loan status", "Number of customers", "banking_loan_status.png")
    save_scatter(bank, "Income", "Credit_Score",
                 "Income vs Credit Score", "banking_income_credit_score.png")
    for c in ["Income", "Credit_Score", "Loan_Amount"]:
        save_hist_box(bank, c, "banking")

    # 5. Agriculture
    agri = frames["agriculture"]
    print("\nAverage crop yield by soil type:\n",
          agri.groupby("Soil_Type")["Crop_Yield_kg"].agg(["count", "mean", "min", "max"]).round(2))
    save_bar(agri.groupby("Soil_Type")["Crop_Yield_kg"].mean(),
             "Average Crop Yield by Soil Type", "Soil type",
             "Average crop yield (kg)", "agriculture_yield_by_soil.png")
    save_scatter(agri, "Rainfall_mm", "Crop_Yield_kg",
                 "Rainfall vs Crop Yield", "agriculture_rainfall_yield.png")
    save_scatter(agri, "Fertilizer_kg", "Crop_Yield_kg",
                 "Fertilizer vs Crop Yield", "agriculture_fertilizer_yield.png")
    for c in ["Rainfall_mm", "Temperature", "Fertilizer_kg", "Crop_Yield_kg"]:
        save_hist_box(agri, c, "agriculture")

    print(f"\nAnalysis complete. Charts saved in: {OUT}")

if __name__ == "__main__":
    main()
