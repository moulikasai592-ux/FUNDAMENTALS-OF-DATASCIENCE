# CO3 AT3 – Fundamentals of Data Science

This repository contains simple-English text answers for all 20 case studies (A, B and C) from the assessment PDF **CO3 AT3 QUESTION FODS.pdf**.

## Files
- `ANSWERS.txt` – Complete text-format answers for all 60 questions.
- `README.md` – Project description and instructions.

## Topics covered
Descriptive statistics, distribution analysis, outlier detection and handling,
hypothesis testing, confidence intervals, one-sample tests, two-sample tests,
proportion tests and chi-square tests.

## Important
The assessment question paper provides scenarios and questions, but no numerical
datasets. Therefore, this answer file explains the correct analysis methods and
decision rules. It does not invent sample statistics, p-values or final numerical
test outcomes.

## Upload to GitHub
1. Extract the downloaded ZIP file.
2. Open GitHub and create a new repository.
3. Upload `README.md` and `ANSWERS.txt`.
4. Commit the changes.
