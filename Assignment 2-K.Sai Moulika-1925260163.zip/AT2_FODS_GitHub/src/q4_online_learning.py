"""Q4: Online learning performance — illustrative data."""
from pathlib import Path
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

OUT = Path("outputs"); OUT.mkdir(exist_ok=True)
df = pd.DataFrame({
    "student": ["S01","S02","S03","S04","S05","S06"],
    "login_date": ["2026-11-01","2026-11-02","2026-11-02","2026-11-03","2026-11-04","2026-11-04"],
    "video_completion_pct": [95, 70, 45, 88, 60, 100],
    "quiz_score": [92, 74, None, 86, 58, 97],
    "assignment_submitted": [True, True, False, True, True, True],
})
df["login_date"] = pd.to_datetime(df["login_date"], errors="coerce")
df["quiz_score"] = pd.to_numeric(df["quiz_score"], errors="coerce")
# Missing means unrecorded/not attempted; keep separate rather than automatically assigning zero.
df["quiz_missing"] = df["quiz_score"].isna()
df["performance_category"] = pd.cut(
    df["quiz_score"], bins=[-0.01, 39.99, 69.99, 84.99, 100],
    labels=["Needs Improvement", "Developing", "Good", "Excellent"]
)
df["quiz_rank"] = df["quiz_score"].rank(ascending=False, method="min")
print(df.sort_values("quiz_score", ascending=False, na_position="last"))
print("\nStudents with >=80% video completion:\n", df[df.video_completion_pct >= 80])
sns.histplot(data=df, x="quiz_score", bins=5)
plt.title("Quiz score distribution"); plt.tight_layout()
plt.savefig(OUT/"q4_quiz_distribution.png"); plt.close()
sns.scatterplot(data=df, x="video_completion_pct", y="quiz_score", hue="performance_category")
plt.title("Video completion and quiz score"); plt.tight_layout()
plt.savefig(OUT/"q4_engagement_vs_score.png"); plt.close()
