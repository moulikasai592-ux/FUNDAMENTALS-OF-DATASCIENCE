"""Q3: Smart energy monitoring — illustrative data."""
from pathlib import Path
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

OUT = Path("outputs"); OUT.mkdir(exist_ok=True)
df = pd.DataFrame({
    "date": ["2026-11-01","2026-11-01","2026-11-01","2026-11-02","2026-11-02","2026-11-02","2026-11-03","2026-11-03"],
    "appliance": ["AC","Fan","Light","AC","Fan","Light","AC","Refrigerator"],
    "units_kwh": [4.2, 0.8, 0.5, 5.1, None, 0.6, 4.7, 1.4],
})
df["date"] = pd.to_datetime(df["date"], errors="coerce")
df["units_kwh"] = pd.to_numeric(df["units_kwh"], errors="coerce")
df = df.drop_duplicates()
# Demonstration imputation: appliance median; preserve missingness if using real data.
df["units_kwh"] = df.groupby("appliance")["units_kwh"].transform(lambda s: s.fillna(s.median()))
df = df[df["units_kwh"].between(0, 30)]  # example plausibility limit; adapt to device
daily_appliance = df.groupby(["date", "appliance"], as_index=False)["units_kwh"].sum()
daily_total = df.groupby("date", as_index=False)["units_kwh"].sum()
print("Daily appliance usage:\n", daily_appliance)
print("\nDaily total:\n", daily_total)
sns.lineplot(data=daily_total, x="date", y="units_kwh", marker="o")
plt.ylabel("Energy (kWh)"); plt.title("Daily electricity consumption")
plt.tight_layout(); plt.savefig(OUT/"q3_daily_consumption.png"); plt.close()
sns.barplot(data=daily_appliance, x="appliance", y="units_kwh", errorbar=None)
plt.ylabel("Energy (kWh)"); plt.title("Total consumption by appliance")
plt.tight_layout(); plt.savefig(OUT/"q3_appliance_consumption.png"); plt.close()
