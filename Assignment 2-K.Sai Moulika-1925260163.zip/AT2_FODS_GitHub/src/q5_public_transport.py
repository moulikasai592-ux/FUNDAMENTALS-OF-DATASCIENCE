"""Q5: Public transport passenger analysis — illustrative data."""
from pathlib import Path
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

OUT = Path("outputs"); OUT.mkdir(exist_ok=True)
df = pd.DataFrame({
    "record_id": [1,2,3,4,5,6,6,7],
    "route": ["21A","21A","5C","5C","12B","12B","12B","21A"],
    "stop": ["Central","Market","Central","Park","Market","Central","Central","Park"],
    "timestamp": ["2026-11-10 08:00","2026-11-10 09:00","2026-11-10 08:00","2026-11-10 18:00",
                  "2026-11-10 17:00","2026-11-10 08:00","2026-11-10 08:00","2026-11-10 18:00"],
    "passenger_count": [45,30,52,60,72,65,65,None],
})
df = df.drop_duplicates(subset=["record_id"])
df["route"] = df["route"].astype("string").str.strip().str.upper()
df["timestamp"] = pd.to_datetime(df["timestamp"], errors="coerce")
df["passenger_count"] = pd.to_numeric(df["passenger_count"], errors="coerce")
df.loc[df["passenger_count"] < 0, "passenger_count"] = float("nan")
df["time_slot"] = df["timestamp"].dt.hour.map(
    lambda h: "Morning peak" if 7 <= h < 11 else ("Evening peak" if 16 <= h < 20 else "Off-peak")
)
print("Passenger totals by route:\n", df.groupby("route")["passenger_count"].sum())
print("\nBy route and time slot:\n", df.groupby(["route","time_slot"])["passenger_count"].sum())
route_totals = df.groupby("route", as_index=False)["passenger_count"].sum()
sns.barplot(data=route_totals, x="route", y="passenger_count")
plt.ylabel("Passengers"); plt.title("Passenger count by route")
plt.tight_layout(); plt.savefig(OUT/"q5_passengers_by_route.png"); plt.close()
pivot = df.pivot_table(index="route", columns="time_slot", values="passenger_count", aggfunc="sum")
sns.heatmap(pivot, annot=True, fmt=".0f", cmap="Blues")
plt.title("Passenger flow by route and time slot")
plt.tight_layout(); plt.savefig(OUT/"q5_route_time_heatmap.png"); plt.close()
