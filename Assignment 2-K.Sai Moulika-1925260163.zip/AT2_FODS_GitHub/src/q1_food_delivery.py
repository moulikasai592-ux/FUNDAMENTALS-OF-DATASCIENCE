"""Q1: Online food delivery analysis — illustrative data."""
from pathlib import Path
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

OUT = Path("outputs"); OUT.mkdir(exist_ok=True)
df = pd.DataFrame({
    "order_id": [101, 102, 103, 104, 104, 105, 106],
    "restaurant": ["Aroma", "Spice Hub", "Aroma", "Green Bowl", "Green Bowl", "Spice Hub", "Aroma"],
    "price": [240, 180, -20, 320, 320, 150, 210],
    "delivery_minutes": [35, 52, 40, None, None, 28, 48],
    "rating": [5, 4, 3, 5, 5, 4, 2],
})
df["price"] = pd.to_numeric(df["price"], errors="coerce")
df["delivery_minutes"] = pd.to_numeric(df["delivery_minutes"], errors="coerce")
df = df.drop_duplicates(subset=["order_id"])
df.loc[df["price"] <= 0, "price"] = float("nan")  # flag invalid prices
df["delivery_minutes"] = df["delivery_minutes"].fillna(df["delivery_minutes"].median())
print("Cleaned orders:\n", df)
print("\nDelayed orders (>45 min):\n", df[df.delivery_minutes > 45])
print("\nAverage delivery time by restaurant:\n", df.groupby("restaurant").delivery_minutes.mean())
sns.barplot(data=df, x="restaurant", y="delivery_minutes", errorbar=None)
plt.ylabel("Delivery time (minutes)"); plt.title("Average delivery time by restaurant")
plt.tight_layout(); plt.savefig(OUT/"q1_delivery_by_restaurant.png"); plt.close()
sns.histplot(data=df, x="delivery_minutes", bins=5)
plt.title("Delivery-time distribution"); plt.tight_layout()
plt.savefig(OUT/"q1_delivery_distribution.png"); plt.close()
