"""Q2: Bank loan approval analysis — illustrative data."""
from pathlib import Path
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

OUT = Path("outputs"); OUT.mkdir(exist_ok=True)
df = pd.DataFrame({
    "income": [45000, 62000, None, 38000, 90000, 54000],
    "loan_amount": [120000, 150000, 80000, 95000, 200000, 110000],
    "credit_score": [720, 680, 640, 610, 780, 700],
    "approval_status": ["Approved", "Approved", "Rejected", "Rejected", "Approved", "Approved"],
    "gender": ["F", "M", "F", "M", "F", "M"],
    "employment_type": ["Salaried", "Self-employed", "Salaried", "Contract", "Salaried", "Contract"],
})
df["income"] = pd.to_numeric(df["income"], errors="coerce")
df["income_missing"] = df["income"].isna().astype(int)
df["income"] = df["income"].fillna(df["income"].median())
df = pd.get_dummies(df, columns=["gender", "employment_type"], dtype=int)
df["loan_amount_minmax"] = (df["loan_amount"] - df["loan_amount"].min()) / (df["loan_amount"].max() - df["loan_amount"].min())
print(df)
print("\nGroup averages:\n", df.groupby("approval_status")[["income", "loan_amount", "credit_score"]].mean())
sns.boxplot(data=df, x="approval_status", y="credit_score")
plt.title("Credit score by loan approval status"); plt.tight_layout()
plt.savefig(OUT/"q2_credit_score_by_status.png"); plt.close()
sns.boxplot(data=df, x="approval_status", y="income")
plt.title("Income by loan approval status"); plt.tight_layout()
plt.savefig(OUT/"q2_income_by_status.png"); plt.close()
