# Assessment Answers — Fundamentals of Data Science (DSA04)

## 1. Online Food Delivery Data Analysis

### A. Using Pandas to read, clean, and filter order data
Pandas provides `read_csv()` to load order records into a DataFrame. The `head()`, `info()`, and `describe()` methods help inspect the dataset. Columns such as order ID, restaurant, order price, delivery time, and customer rating can be selected using `df[[...]]`. Boolean conditions can filter delayed orders, orders from a particular restaurant, or orders above a chosen price.

Example:
```python
import pandas as pd
orders = pd.read_csv("food_orders.csv")
orders = orders[["order_id", "restaurant", "price", "delivery_minutes", "rating"]]
delayed = orders[orders["delivery_minutes"] > 45]
```

### B. Data preprocessing
- **Missing delivery time:** Convert the column to numeric and replace missing values with the median for the relevant restaurant or, if that is not practical, the overall median. If delivery time is the target being studied, mark imputed values so they are not mistaken for observed values.
- **Duplicate orders:** Use `drop_duplicates(subset=["order_id"])` when order ID uniquely identifies an order.
- **Incorrect prices:** Convert prices to numeric, flag zero or negative values and implausible outliers, and verify them against the source system. Do not silently replace a price unless a valid correction is available.

### C. Visualization
Matplotlib or Seaborn can show delivery-time distributions with histograms or box plots, average delays by restaurant with bar charts, and customer ratings with count plots or box plots. Labels, titles, and units make the charts understandable. A bar chart of mean delivery time by restaurant can help identify where delays are most common.

## 2. Bank Loan Approval Analysis

### A. Pandas DataFrame operations
Load application data using `pd.read_csv()`. Select `income`, `loan_amount`, `credit_score`, and `approval_status` with column indexing. Use `loc` to filter approved or rejected applications, `sort_values()` to order by income or credit score, and `groupby("approval_status")` to compare group averages.

### B. Preprocessing
- **Missing income:** Convert to numeric and impute with a suitable statistic such as the median, preferably calculated within a relevant group where justified. Keep a missing-value indicator if missingness may carry information.
- **Gender/employment type:** Treat these as categorical variables. Use one-hot encoding with `pd.get_dummies()` or a preprocessing encoder. Avoid assigning arbitrary numeric order to categories.
- **Normalize loan amount:** Apply Min-Max scaling to map values to a 0–1 range, or standardization to produce values centered around zero with unit variance. Fit scaling parameters on training data only when building a predictive model.

### C. Visualization
Use box plots or violin plots to compare income, credit score, and loan amount across approval status. Histograms can show distributions, and grouped bar charts can compare average values. Charts describe associations in the dataset; they do not prove that a particular attribute causes approval or rejection.

## 3. Smart Energy Consumption Monitoring

### A. Grouping with Pandas
Convert the date column to datetime using `pd.to_datetime()`. Use `groupby(["date", "appliance"])["units_kwh"].sum()` to calculate daily usage by appliance. A pivot table can place dates in rows and appliances in columns for easier comparison.

### B. Preprocessing
- Convert readings to numeric and dates to datetime.
- Remove exact duplicate records using `drop_duplicates()`.
- Identify abnormal readings using domain-specific limits and investigate them before exclusion. A negative energy reading may be invalid, while a high reading may be real.
- Fill missing readings with a justified method, such as a time-based interpolation for a short gap or a group median. Document the method.
- Calculate total consumption by date using `groupby("date")["units_kwh"].sum()`.

### C. Visualization
A line chart shows daily total consumption and makes trends or unusual changes visible. A bar chart of total kWh by appliance identifies appliances with the highest recorded usage. Include kWh units and clear date labels.

## 4. Online Learning Platform Performance Analysis

### A. Sorting, filtering, and ranking
Use Pandas to sort students by quiz score or completion percentage with `sort_values()`. Filter students who meet a defined completion threshold. Use `rank(ascending=False)` to rank students by quiz score. If a combined ranking is needed, define and explain the weighting rather than combining measures without justification.

### B. Preprocessing
- Convert quiz scores to numeric and handle missing scores by checking whether they mean “not attempted” or “not recorded.” Do not automatically treat both as zero.
- Convert login/submission date fields with `pd.to_datetime(..., errors="coerce")`.
- Create a performance category using defined score ranges, for example: below 40 = Needs Improvement, 40–69 = Developing, 70–84 = Good, and 85–100 = Excellent. These are example bands and should be adjusted to the institution's grading policy.
- Create a completion percentage only after defining the numerator and denominator consistently.

### C. Visualization
Use Seaborn histograms to show quiz-score distribution, count plots to compare performance categories, and bar charts to compare completion status. A scatter plot can explore the relationship between video completion and quiz score. Matplotlib can create line charts of engagement over time.

## 5. Public Transport Passenger Data Analysis

### A. Pandas analysis
Load passenger records and select route, stop, timestamp/time slot, and passenger count columns. Group by route, stop, and time slot to calculate totals and averages. Use `pivot_table()` to compare passenger counts across routes and time periods. Sort the grouped results to identify the busiest routes and stops.

### B. Preprocessing
- Convert route numbers to a consistent string format and validate them against the official route list.
- Convert passenger counts to numeric and flag negative or impossible values. Fill missing counts only where a defensible estimate exists; otherwise retain them as missing and report the gap.
- Remove duplicate records using the actual unique key, such as a record ID or a combination of route, stop, timestamp, and trip ID.
- Parse timestamps with `pd.to_datetime()` and derive time slots such as morning peak, afternoon, and evening.

### C. Visualization
A line chart can show passenger flow over time, a bar chart can compare total passengers by route, and a heatmap can show passenger counts by route and time slot. These visualizations help identify peak hours, busy routes, and stops that may need capacity or scheduling review.

## Conclusion

Pandas supports data loading, selection, filtering, grouping, cleaning, and transformation. Matplotlib and Seaborn turn the cleaned data into charts that make patterns easier to understand. Reliable analysis depends on checking data quality, choosing preprocessing methods that fit the data, documenting assumptions, and labeling visualizations clearly.
