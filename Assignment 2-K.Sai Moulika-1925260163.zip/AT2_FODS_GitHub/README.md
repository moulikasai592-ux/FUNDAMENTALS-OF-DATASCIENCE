# Fundamentals of Data Science — Assessment Tool 2

**Course:** Fundamentals of Data Science  
**Course code:** DSA04  
**Outcome:** CO2 — Apply data pre-processing and visualization techniques using Python libraries for effective data handling.

This repository contains written answers and runnable Python examples for all five analytical problem-solving questions in the assessment.

## Repository structure

```text
AT2_FODS_GitHub/
├── README.md
├── requirements.txt
├── assessment_answers.md
├── src/
│   ├── q1_food_delivery.py
│   ├── q2_bank_loan.py
│   ├── q3_energy_consumption.py
│   ├── q4_online_learning.py
│   └── q5_public_transport.py
└── data/
    └── README.md
```

## Setup

1. Install Python 3.9 or later.
2. Open a terminal in this folder.
3. Install dependencies:

   ```bash
   pip install -r requirements.txt
   ```

4. Run any example, for example:

   ```bash
   python src/q1_food_delivery.py
   ```

Each script creates a small demonstration dataset in memory, demonstrates cleaning and analysis, and saves charts in a `outputs/` folder. Replace the demonstration records with your actual dataset when available.

## Important

- The datasets in these scripts are illustrative sample data, not real customer, bank, student, passenger, or household records.
- Cleaning rules should be adapted to the meaning and valid ranges of the real dataset.
- Review the answers, run the scripts, and add your own name, registration number, and signature to the assessment's code-of-conduct section before submission.


## Completed assessment documents

Editable Word and PDF copies are included in `submission/`. Fill in your own name and register number, review the work, and sign the declaration yourself.
