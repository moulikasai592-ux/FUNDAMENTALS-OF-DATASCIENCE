# Fundamentals of Data Science – Assignment 5

**Course:** Fundamentals of Data Science  
**Course Code:** DSA0401  
**Student:** K. Sai Moulika

## About
This repository contains the submitted Assignment 5 document for the Fundamentals of Data Science course.

## Assignment contents
The document covers scenario-based data science solutions, including:

1. AI-Based Crop Advisory Reliability Assessment
2. Smart Public Health Risk Prioritization
3. Urban Traffic Congestion and Emergency Route Evaluation
4. Smart Waste Collection Prioritization System
5. Air Quality Prediction and Pollution-Control Decision Support
6. Smart Water Supply and Leakage Risk Assessment
7. Learning Outcome and Dropout-Risk Evaluation for Government Schools
8. Smart Disaster Early-Warning Reliability System
9. Public Distribution System Anomaly and Leakage Detection
10. Smart Energy Demand Forecasting for Public Buildings

## Repository structure

```text
Assignment_5_GitHub/
├── README.md
├── .gitignore
└── docs/
    └── Assignment_5_Fundamentals_of_Data_Science.docx
```

## How to use
Open the Word document inside the `docs` folder to view the complete assignment.
